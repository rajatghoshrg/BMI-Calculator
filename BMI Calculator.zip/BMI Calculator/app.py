# BMI Calculator 
# Developed by Rajat Ghosh
# Date: July 2025

from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    bmi = None
    condition = None

    if request.method == "POST":
        try:
            age = float(request.form["age"])
            height = float(request.form["height"])
            weight = float(request.form["weight"])

            if age <= 0 or height <= 0 or weight <= 0:
                condition = "Please enter your details correctly!"
            else:
                bmi = round(weight / ((height / 100) ** 2), 2)

                if age < 19:
                    if bmi < 14:
                        condition = "🟠Under Weight"
                    elif 14 <= bmi < 19:
                        condition = "🟢Normal Weight"
                    elif 19 <= bmi < 24:
                        condition = "🟠Over Weight"
                    else:
                        condition = "🔴Obesity"
                else:
                    if bmi < 18.5:
                        condition = "🟠Under Weight"
                    elif 18.5 <= bmi < 24.9:
                        condition = "🟢Normal Weight"
                    elif 24.9 <= bmi < 29.9:
                        condition = "🟡Over Weight"
                    elif 29.9 <= bmi < 34.9:
                        condition = "🟠Obesity Class 1"
                    elif 34.9 <= bmi < 39.9:
                        condition = "🔴Obesity Class 2"
                    else:
                        condition = "🔴Extremely Obese"

        except ValueError:
            condition = "Invalid entry! Please enter your details correctly."

    return render_template("index.html", condition=condition, bmi=bmi)

if __name__ == "__main__":
    app.run(debug=True)
